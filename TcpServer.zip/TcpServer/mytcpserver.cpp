#include "mytcpserver.h"

MyTcpServer::MyTcpServer()
{


}

MyTcpServer &MyTcpServer::getInstance()
{
    static MyTcpServer instance;
    return instance;
}
